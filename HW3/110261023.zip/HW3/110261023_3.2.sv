// Code your design here
module FullAdder (
    output logic sum,
    output logic cout,
    input  logic a,
    input  logic b,
    input  logic cin
);
    
    assign sum  = a ^ b ^ cin;
    assign cout = (a & b) | (b & cin) | (a & cin);
endmodule


module CSA_14 (
    output logic [13:0] s_o,
    output logic        c_o,
    input  logic [13:0] a_i,
    input  logic [13:0] b_i,
    input  logic        c_i
);

    logic [3:0] cout;

    // Block 1: bits 0–1
    FullAdder FA0(s_o[0], cout[0], a_i[0], b_i[0], c_i);
    FullAdder FA1(s_o[1], cout[1], a_i[1], b_i[1], cout[0]);

    // Block 2: bits 2–4
    logic [2:0] s20, s21, c20, c21;

    // Carry=0
    FullAdder FA2(s20[0], c20[0], a_i[2], b_i[2], 1'b0);
    FullAdder FA3(s20[1], c20[1], a_i[3], b_i[3], c20[0]);
    FullAdder FA4(s20[2], c20[2], a_i[4], b_i[4], c20[1]);

    // Carry=1
    FullAdder FA5(s21[0], c21[0], a_i[2], b_i[2], 1'b1);
    FullAdder FA6(s21[1], c21[1], a_i[3], b_i[3], c21[0]);
    FullAdder FA7(s21[2], c21[2], a_i[4], b_i[4], c21[1]);

    assign s_o[2] = cout[1] ? s21[0] : s20[0];
    assign s_o[3] = cout[1] ? s21[1] : s20[1];
    assign s_o[4] = cout[1] ? s21[2] : s20[2];

    assign cout[2] = cout[1] ? c21[2] : c20[2];

    // Block 3: bits 5–8
    logic [3:0] s30, s31, c30, c31;

    // Carry=0
    FullAdder FA8 (s30[0], c30[0], a_i[5], b_i[5], 1'b0);
    FullAdder FA9 (s30[1], c30[1], a_i[6], b_i[6], c30[0]);
    FullAdder FA10(s30[2], c30[2], a_i[7], b_i[7], c30[1]);
    FullAdder FA11(s30[3], c30[3], a_i[8], b_i[8], c30[2]);

    // Carry=1
    FullAdder FA12(s31[0], c31[0], a_i[5], b_i[5], 1'b1);
    FullAdder FA13(s31[1], c31[1], a_i[6], b_i[6], c31[0]);
    FullAdder FA14(s31[2], c31[2], a_i[7], b_i[7], c31[1]);
    FullAdder FA15(s31[3], c31[3], a_i[8], b_i[8], c31[2]);

    assign s_o[5] = cout[2] ? s31[0] : s30[0];
    assign s_o[6] = cout[2] ? s31[1] : s30[1];
    assign s_o[7] = cout[2] ? s31[2] : s30[2];
    assign s_o[8] = cout[2] ? s31[3] : s30[3];

    assign cout[3] = cout[2] ? c31[3] : c30[3];

    // Block 4: bits 9–13
    logic [4:0] s40, s41, c40, c41;

    // Carry=0
    FullAdder FA16(s40[0], c40[0], a_i[9],  b_i[9],  1'b0);
    FullAdder FA17(s40[1], c40[1], a_i[10], b_i[10], c40[0]);
    FullAdder FA18(s40[2], c40[2], a_i[11], b_i[11], c40[1]);
    FullAdder FA19(s40[3], c40[3], a_i[12], b_i[12], c40[2]);
    FullAdder FA20(s40[4], c40[4], a_i[13], b_i[13], c40[3]);

    // Carry=1
    FullAdder FA21(s41[0], c41[0], a_i[9],  b_i[9],  1'b1);
    FullAdder FA22(s41[1], c41[1], a_i[10], b_i[10], c41[0]);
    FullAdder FA23(s41[2], c41[2], a_i[11], b_i[11], c41[1]);
    FullAdder FA24(s41[3], c41[3], a_i[12], b_i[12], c41[2]);
    FullAdder FA25(s41[4], c41[4], a_i[13], b_i[13], c41[3]);

    assign s_o[9]  = cout[3] ? s41[0] : s40[0];
    assign s_o[10] = cout[3] ? s41[1] : s40[1];
    assign s_o[11] = cout[3] ? s41[2] : s40[2];
    assign s_o[12] = cout[3] ? s41[3] : s40[3];
    assign s_o[13] = cout[3] ? s41[4] : s40[4];

    assign c_o = cout[3] ? c41[4] : c40[4];

endmodule
