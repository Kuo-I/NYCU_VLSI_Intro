// Code your design here
module BKT_16 (
    output logic [15:0] s_o,
    output logic        c_o,
    input  logic [15:0] a_i,
    input  logic [15:0] b_i
);

    // Declare propagate and generate signals
    logic [15:0] p, g;
    logic [15:0] c;
    logic [15:0] G1, P1, G2, G3;

    // Manually assign propagate and generate (unrolled)
    assign p[0]  = a_i[0]  ^ b_i[0];  assign g[0]  = a_i[0]  & b_i[0];
    assign p[1]  = a_i[1]  ^ b_i[1];  assign g[1]  = a_i[1]  & b_i[1];
    assign p[2]  = a_i[2]  ^ b_i[2];  assign g[2]  = a_i[2]  & b_i[2];
    assign p[3]  = a_i[3]  ^ b_i[3];  assign g[3]  = a_i[3]  & b_i[3];
    assign p[4]  = a_i[4]  ^ b_i[4];  assign g[4]  = a_i[4]  & b_i[4];
    assign p[5]  = a_i[5]  ^ b_i[5];  assign g[5]  = a_i[5]  & b_i[5];
    assign p[6]  = a_i[6]  ^ b_i[6];  assign g[6]  = a_i[6]  & b_i[6];
    assign p[7]  = a_i[7]  ^ b_i[7];  assign g[7]  = a_i[7]  & b_i[7];
    assign p[8]  = a_i[8]  ^ b_i[8];  assign g[8]  = a_i[8]  & b_i[8];
    assign p[9]  = a_i[9]  ^ b_i[9];  assign g[9]  = a_i[9]  & b_i[9];
    assign p[10] = a_i[10] ^ b_i[10]; assign g[10] = a_i[10] & b_i[10];
    assign p[11] = a_i[11] ^ b_i[11]; assign g[11] = a_i[11] & b_i[11];
    assign p[12] = a_i[12] ^ b_i[12]; assign g[12] = a_i[12] & b_i[12];
    assign p[13] = a_i[13] ^ b_i[13]; assign g[13] = a_i[13] & b_i[13];
    assign p[14] = a_i[14] ^ b_i[14]; assign g[14] = a_i[14] & b_i[14];
    assign p[15] = a_i[15] ^ b_i[15]; assign g[15] = a_i[15] & b_i[15];

    // Stage 1
    assign G1[1]  = g[1]  | (p[1]  & g[0]);    assign P1[1]  = p[1]  & p[0];
    assign G1[3]  = g[3]  | (p[3]  & g[2]);    assign P1[3]  = p[3]  & p[2];
    assign G1[5]  = g[5]  | (p[5]  & g[4]);    assign P1[5]  = p[5]  & p[4];
    assign G1[7]  = g[7]  | (p[7]  & g[6]);    assign P1[7]  = p[7]  & p[6];
    assign G1[9]  = g[9]  | (p[9]  & g[8]);    assign P1[9]  = p[9]  & p[8];
    assign G1[11] = g[11] | (p[11] & g[10]);   assign P1[11] = p[11] & p[10];
    assign G1[13] = g[13] | (p[13] & g[12]);   assign P1[13] = p[13] & p[12];
    assign G1[15] = g[15] | (p[15] & g[14]);   assign P1[15] = p[15] & p[14];

    // Stage 2
    assign G2[3]  = G1[3]  | (P1[3]  & G1[1]);
    assign G2[7]  = G1[7]  | (P1[7]  & G1[5]);
    assign G2[11] = G1[11] | (P1[11] & G1[9]);
    assign G2[15] = G1[15] | (P1[15] & G1[13]);

    // Stage 3
    assign G3[7]  = G2[7]  | (P1[7]  & G2[3]);
    assign G3[15] = G2[15] | (P1[15] & G2[11]);

    // Carry bits
    assign c[0]  = 1'b0;
    assign c[1]  = g[0];
    assign c[2]  = G1[1];
    assign c[3]  = g[2]  | (p[2] & G1[1]);
    assign c[4]  = G2[3];
    assign c[5]  = g[4]  | (p[4] & G2[3]);
    assign c[6]  = G1[5] | (P1[5] & G2[3]);
    assign c[7]  = g[6]  | (p[6] & G1[5]) | (p[6] & P1[5] & G2[3]);
    assign c[8]  = G3[7];
    assign c[9]  = g[8]  | (p[8] & G3[7]);
    assign c[10] = G1[9] | (P1[9] & G3[7]);
    assign c[11] = g[10] | (p[10] & G1[9]) | (p[10] & P1[9] & G3[7]);
    assign c[12] = G2[11];
    assign c[13] = g[12] | (p[12] & G2[11]);
    assign c[14] = G1[13] | (P1[13] & G2[11]);
    assign c[15] = g[14] | (p[14] & G1[13]) | (p[14] & P1[13] & G2[11]);

    // Final carry-out
    assign c_o = G3[15];

    // Sum bits (XOR of propagate and carry)
    assign s_o[0]  = p[0];
    assign s_o[1]  = p[1]  ^ c[1];
    assign s_o[2]  = p[2]  ^ c[2];
    assign s_o[3]  = p[3]  ^ c[3];
    assign s_o[4]  = p[4]  ^ c[4];
    assign s_o[5]  = p[5]  ^ c[5];
    assign s_o[6]  = p[6]  ^ c[6];
    assign s_o[7]  = p[7]  ^ c[7];
    assign s_o[8]  = p[8]  ^ c[8];
    assign s_o[9]  = p[9]  ^ c[9];
    assign s_o[10] = p[10] ^ c[10];
    assign s_o[11] = p[11] ^ c[11];
    assign s_o[12] = p[12] ^ c[12];
    assign s_o[13] = p[13] ^ c[13];
    assign s_o[14] = p[14] ^ c[14];
    assign s_o[15] = p[15] ^ c[15];

endmodule
