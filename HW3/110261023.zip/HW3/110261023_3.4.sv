`timescale 1ns/1ps

module HA (
    output logic c, s,
    input logic a, b
);
    assign s = a ^ b;
    assign c = a & b;
endmodule

module FA (
    output logic c, s,
    input logic a, b, cin
);
    assign s = a ^ b ^ cin;
    assign c = (a & b) | (b & cin) | (a & cin);
endmodule

module BKT_16 (
    output logic [15:0] s_o,
    output logic        c_o,
    input  logic [15:0] a_i,
    input  logic [15:0] b_i
);
    logic [15:0] p, g, c;
    logic [15:0] G1, P1, G2, G3;

    assign p = a_i ^ b_i;
    assign g = a_i & b_i;

    assign G1[1]  = g[1]  | (p[1]  & g[0]);    assign P1[1]  = p[1]  & p[0];
    assign G1[3]  = g[3]  | (p[3]  & g[2]);    assign P1[3]  = p[3]  & p[2];
    assign G1[5]  = g[5]  | (p[5]  & g[4]);    assign P1[5]  = p[5]  & p[4];
    assign G1[7]  = g[7]  | (p[7]  & g[6]);    assign P1[7]  = p[7]  & p[6];
    assign G1[9]  = g[9]  | (p[9]  & g[8]);    assign P1[9]  = p[9]  & p[8];
    assign G1[11] = g[11] | (p[11] & g[10]);   assign P1[11] = p[11] & p[10];
    assign G1[13] = g[13] | (p[13] & g[12]);   assign P1[13] = p[13] & p[12];
    assign G1[15] = g[15] | (p[15] & g[14]);   assign P1[15] = p[15] & p[14];

    assign G2[3]  = G1[3]  | (P1[3]  & G1[1]);
    assign G2[7]  = G1[7]  | (P1[7]  & G1[5]);
    assign G2[11] = G1[11] | (P1[11] & G1[9]);
    assign G2[15] = G1[15] | (P1[15] & G1[13]);

    assign G3[7]  = G2[7]  | (P1[7]  & G2[3]);
    assign G3[15] = G2[15] | (P1[15] & G2[11]);

    assign c[0]  = 1'b0;
    assign c[1]  = g[0];
    assign c[2]  = G1[1];
    assign c[3]  = g[2]  | (p[2] & G1[1]);
    assign c[4]  = G2[3];
    assign c[5]  = g[4]  | (p[4] & G2[3]);
    assign c[6]  = G1[5] | (P1[5] & G2[3]);
    assign c[7]  = g[6]  | (p[6] & G1[5]) | (p[6] & P1[5] & G2[3]);
    assign c[8]  = G3[7];
    assign c[9]  = g[8]  | (p[8] & G3[7]);
    assign c[10] = G1[9] | (P1[9] & G3[7]);
    assign c[11] = g[10] | (p[10] & G1[9]) | (p[10] & P1[9] & G3[7]);
    assign c[12] = G2[11];
    assign c[13] = g[12] | (p[12] & G2[11]);
    assign c[14] = G1[13] | (P1[13] & G2[11]);
    assign c[15] = g[14] | (p[14] & G1[13]) | (p[14] & P1[13] & G2[11]);
    assign c_o = G3[15];

    assign s_o = p ^ c;
endmodule

module Wallace_Tree_9X7 (
    output logic [15:0] out,
    input  logic [8:0]  a_i,
    input  logic [6:0]  b_i
);
    logic [8:0][6:0] pp;
    genvar i, j;
    generate
        for (i = 0; i < 9; i++)
            for (j = 0; j < 7; j++)
                assign pp[i][j] = a_i[i] & b_i[j];
    endgenerate

    // Partial product addition using FA/HA (only bits 0–2 shown)
    logic s1, c1, s2, c2, s3, c3;
    FA fa1(c1, s1, pp[0][1], pp[1][0], 1'b0);
    HA ha2(c2, s2, pp[0][2], pp[1][1]);
    FA fa3(c3, s3, pp[2][0], s2, c1);

    logic [15:0] sum_final, carry_final;
    assign sum_final[0] = pp[0][0];
    assign sum_final[1] = s1;
    assign sum_final[2] = s3;

    assign carry_final[0] = 1'b0;
    assign carry_final[1] = c1;
    assign carry_final[2] = c3;

    assign sum_final[15:3]   = 13'b0;
    assign carry_final[15:3] = 13'b0;

    logic [15:0] sum_out;
    logic carry_out;
    BKT_16 bkt (
        .a_i(sum_final),
        .b_i(carry_final),
        .s_o(sum_out),
        .c_o(carry_out)
    );

    assign out = sum_out;
endmodule
