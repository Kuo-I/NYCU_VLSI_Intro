# Introduction to VLSI: Final Project

## Project Title: Optimized Pipelined Multiply-and-Add Unit Implementation

## 1. Project Description

The objective of this final project is to design and implement a pipelined multiply-and-add (MAU) unit with a focus on optimizing Power, Performance, and Area (PPA). You will explore different design alternatives and synthesis strategies to achieve the best possible PPA metric as defined below.

## 2. Design Specifications

The MAU unit should perform the operation $d\_o = a\_i \times b\_i + c\_i$. The inputs $a\_i$ and $b\_i$ are 15-bit unsigned values, and $c\_i$ is a 30-bit unsigned value. The output $d\_o$ will be a 31-bit unsigned result. The module should interface with the system using the following input and output signals:

### 2.1. I/O Description

* `clk`: 1-bit input, clock signal (active high).
* `rst_n`: 1-bit input, asynchronous reset (active low).
* `valid_i`: 1-bit input, indicates that the data on `a_i`, `b_i`, and `c_i` is valid in the current cycle.
* `last_i`: 1-bit input, indicates that the current input data is the last in a burst of data.
* `a_i`: 15-bit input, unsigned operand 'a'.
* `b_i`: 15-bit input, unsigned operand 'b'.
* `c_i`: 30-bit input, unsigned operand 'c'.
* `ready_o`: 1-bit output, indicates that the output data on `d_o` is valid and ready to be consumed.
* `done_o`: 1-bit output, indicates that the current output data on `d_o` is the last in a burst of output data.
* `d_o`: 31-bit output, unsigned result of the multiply-and-add operation ($a\_i \times b\_i + c\_i$).

### 2.2. Block Diagram

The following diagram illustrates the high-level structure of the MAU unit:

![Block Diagram](prj-block.jpg)

### 2.3. Timing Diagram

The diagram below provides an illustrative example of the expected timing behavior and data flow through the pipeline:

![Timing Diagram](prj-timing.png)

## 3. Reference Implementation

A sample project directory is provided to serve as a reference. You can find a sample implementation of the MAU unit in the file `"rtl/mau.v"`. Use this as a starting point for understanding the basic structure and I/O interface, keeping in mind the required changes in bit widths for your design.

## 4. Project Ranking and Optimization

The goal is to minimize the following PPA metric:

$$ \text{PPA} = \text{CLOCK\_PERIOD} \times \text{DIE\_AREA} \times (1 + 0.1 \times \text{NUM\_PIPELINE\_STAGE}) $$

where:

* **CLOCK_PERIOD**: The clock period (in nanoseconds) specified in the `openlane/config.json` file for your optimized design. **Crucially, your *optimized* design must have absolutely no timing violations reported across all process corners for the chosen clock period.**
* **DIE_AREA**: The estimated core area ($μm^2$) of the synthesized and placed *optimized* design. This value can be found in the `"design__die__area"` field within the file `"openlane/runs/<your_run>/final/metric.json"` after a successful OpenLane run of your optimized design.
* **NUM_PIPELINE_STAGE**: The number of pipeline stages in your design. This should correspond to the value of the parameter `D_LAT` defined in your testbench file `"bench/tb_mau.v"`. Ensure that you update this parameter to accurately reflect the latency of your pipelined design for proper verification.

### 4.1. Optimization Strategies

Consider the following strategies to optimize your PPA metric:

1.  **Pipelining:** Experiment with adding a suitable number of pipeline stages within your MAU design. Pipelining can help reduce the critical path delay, allowing for a shorter clock period, while aiming to minimize the increase in die area. Given the increased bit widths, pipelining will be crucial to achieving a reasonable clock frequency.
2.  **Synthesis Strategy Exploration:** Utilize the `openlane/run_openlane_syn_explore.sh` script after developing a new design alternative. This script helps explore different synthesis options provided by Yosys within the OpenLane flow, which can impact area and timing. After exploring the options, modify the `SYNTH_STRATEGY` setting in the `config.json` file to select the strategy that yields the best results for your design.

## 5. Project Deliverables and Requirements

Your final project submission must include:

1.  **A complete project directory:** This should contain all your design files (`.v`), testbenches (`.v`), simulation scripts, and OpenLane configuration files (`config.json`).
2.  **Design Alternatives:** At least three distinct RTL design alternatives for the MAU unit (`mau_v1.v`, `mau_v2.v`, and `mau_v3.v`) located in the `"rtl"` directory. Each version should represent a different approach to pipelining or logic implementation, tailored for the specified 15-bit and 30-bit inputs.
3.  **Optimized Configuration File:** An updated `openlane/config.json` file that is specifically configured for your *most optimized* MAU design version (the one achieving the lowest PPA score). This file should reflect the target clock period for your optimized design.
4.  **RTL Verification:** Ensure that **all** your MAU designs (`mau_v1.v`, `mau_v2.v`, `mau_v3.v`, and your optimized version if it has a different filename) successfully pass the provided RTL verification testbench (`bench/tb_mau.v`). Remember to update the `D_LAT` parameter in the testbench as needed for each design to match its pipeline latency.
5.  **Gate-level Verification:** Perform gate-level simulation using the netlist generated by OpenLane for your optimized design. Copy the netlist file (typically located at `openlane/runs/<your_run>/final/nl/<design_name>.nl.v`) to the `"gl"` directory. Run the gate-level simulation using the appropriate testbench and ensure that it passes, verifying the functionality of the synthesized design.
6.  **Timing Closure:** Verify that your *optimized* design, when synthesized and laid out using OpenLane with the configuration in your submitted `config.json` file (including the target `CLOCK_PERIOD`), has *no timing violations* reported in the final physical design results across all process corners.

## 6. Scoring Policy

Your final project score will be determined based on the following criteria:

1.  **On-time Submission with Full Requirements Met:** If you submit your project by the deadline and successfully fulfill all the requirements outlined in Section 5 (Project Deliverables and Requirements), your score will be between 85 and 95 points. The specific score within this range will be determined by your project's PPA ranking relative to other submissions. A lower PPA score (better optimization) will result in a higher score within this range.
2.  **On-time Submission with Incomplete Requirements:** If you submit your project by the deadline but do not fully meet all the requirements outlined in Section 5, you will receive 80 points.
3.  **Late Submission:** Projects submitted after the deadline will receive a score of less than 60 points.