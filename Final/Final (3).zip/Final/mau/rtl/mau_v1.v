module mau #(
    parameter   D_SIZE = `DATA_SIZE, 
                D_LAT  = `NUM_PIPELINES_STAGE
)(
    input   wire                    clk,
    input   wire                    rst_n,
    input   wire                    valid_i,
    input   wire                    last_i,
    input   wire    [D_SIZE-1:0]    a_i,
    input   wire    [D_SIZE-1:0]    b_i,
    input   wire    [D_SIZE*2-1:0]  c_i,
    output  reg                     ready_o,
    output  reg                     done_o,
    output  wire    [D_SIZE*2:0]    d_o
);

reg                     ready[0:D_LAT+1];
reg                     done[0:D_LAT+1];

reg                    valid_i_d;
reg                    last_i_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        valid_i_d  <= 0;
        last_i_d   <= 0;
    end
    else begin
        valid_i_d  <= valid_i;
        last_i_d   <= last_i;
    end
end

always @* begin
    ready[0]  = valid_i_d;
    done[0]   = last_i_d;
    ready_o   = ready[D_LAT];
    done_o    = done[D_LAT];
end

genvar gen_i;
generate
    for (gen_i=1; gen_i<=D_LAT+1; gen_i=gen_i+1) begin
        always @(posedge clk or negedge rst_n) begin
            if (!rst_n) begin
                ready[gen_i] <= 0;
                done[gen_i]  <= 0;
            end
            else begin
                ready[gen_i] <= ready[gen_i-1];
                done[gen_i]  <= done[gen_i-1];
            end
        end
    end
endgenerate

mau_core #(
    .D_SIZE (15)
) u_mau_core
(
    .clk    (clk),
    .rst_n  (rst_n),
    .a      (a_i),
    .b      (b_i),
    .c      (c_i),
    .out    (d_o)
);

endmodule

module mau_core#(
    parameter D_SIZE = 15 
)(
    input   wire                    clk,
    input   wire                    rst_n,
    input   wire [D_SIZE-1:0]       a,
    input   wire [D_SIZE-1:0]       b,
    input   wire [D_SIZE*2-1:0]     c,
    output  wire [D_SIZE*2:0]       out
);
  // lint_off MULTIPLY
  function [D_SIZE*2-1:0] umul30b_15b_x_15b (input reg [D_SIZE-1:0] lhs, input reg [D_SIZE-1:0] rhs);
    begin
      umul30b_15b_x_15b = lhs * rhs;
    end
  endfunction
  // lint_on MULTIPLY

  // ===== Pipe stage 0:

  // Registers for pipe stage 0:
  reg [D_SIZE-1:0]      p0_a;
  reg [D_SIZE-1:0]      p0_b;
  reg [D_SIZE*2-1:0]    p0_c;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        p0_a <= 0;
        p0_b <= 0;
        p0_c <= 0;
    end
    else begin
        p0_a <= a;
        p0_b <= b;
        p0_c <= c;
    end
  end

  // ===== Pipe stage 1:
  wire [D_SIZE*2-1:0] p1_umul_30_comb;
  assign p1_umul_30_comb = umul30b_15b_x_15b(p0_a, p0_b);

  // Registers for pipe stage 1:
  reg [D_SIZE*2-1:0] p1_c;
  reg [D_SIZE*2-1:0] p1_umul_30;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        p1_c        <= 0;
        p1_umul_30  <= 0;
    end
    else begin
        p1_c        <= p0_c;
        p1_umul_30  <= p1_umul_30_comb;
    end
  end

  // ===== Pipe stage 2:
  wire [D_SIZE*2:0] p2_add_31_comb;
  assign p2_add_31_comb = p1_umul_30 + p1_c;

  // Registers for pipe stage 2:
  reg [D_SIZE*2:0] p2_add_31;
  always @(posedge clk) begin
    if (!rst_n) begin
        p2_add_31 <= 0;
    end
    else begin
        p2_add_31 <= p2_add_31_comb;
    end
  end
  assign out = p2_add_31;

endmodule