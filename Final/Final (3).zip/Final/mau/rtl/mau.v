module mau #(
    parameter D_SIZE = `DATA_SIZE, 
              D_LAT  = `NUM_PIPELINES_STAGE
)(
    input   wire                    clk,
    input   wire                    rst_n,
    input   wire                    valid_i,
    input   wire                    last_i,
    input   wire    [D_SIZE-1:0]    a_i,
    input   wire    [D_SIZE-1:0]    b_i,
    input   wire    [D_SIZE*2-1:0]  c_i,
    output  reg                     ready_o,
    output  reg                     done_o,
    output  reg     [D_SIZE*2:0]    d_o
);

reg                     ready[0:D_LAT+1];
reg                     done[0:D_LAT+1];

reg [D_SIZE*2:0]        pd[0:D_LAT+1];

reg                    valid_i_d;
reg                    last_i_d;
reg    [D_SIZE-1:0]     a_i_d;
reg    [D_SIZE-1:0]     b_i_d;
reg    [D_SIZE*2-1:0]   c_i_d;

always @(posedge clk or negedge rst_n) begin
    if (rst_n==0) begin
        valid_i_d  <= 0;
        last_i_d   <= 0;
        a_i_d      <= 0;
        b_i_d      <= 0;
        c_i_d      <= 0;
    end
    else begin
        valid_i_d  <= valid_i;
        last_i_d   <= last_i;
        a_i_d      <= a_i;
        b_i_d      <= b_i;
        c_i_d      <= c_i;
    end
end

always @* begin
    ready[0]  = valid_i_d;
    done[0]   = last_i_d;
    ready_o   = ready[D_LAT];
    done_o    = done[D_LAT];
    pd[0]     = a_i_d*b_i_d+c_i_d;
    d_o     = pd[D_LAT];
end

genvar gen_i;
generate
    for (gen_i=1; gen_i<=D_LAT+1; gen_i=gen_i+1) begin
        always @(posedge clk or negedge rst_n) begin
            if (rst_n==0) begin
                ready[gen_i] <= 0;
                done[gen_i]  <= 0;
                pd[gen_i]    <= 0;
            end
            else begin
                ready[gen_i] <= ready[gen_i-1];
                done[gen_i]  <= done[gen_i-1];
                pd[gen_i]    <= pd[gen_i-1];
            end
        end
    end
endgenerate

endmodule