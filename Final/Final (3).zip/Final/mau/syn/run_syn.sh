#!/bin/bash

rm -fr ../gl/mau_gl.v

yosys -s yosys_cmd.tcl

mv mau_gl.v ../gl/.