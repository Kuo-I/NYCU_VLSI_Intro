# Read modules from Verilog file
read_verilog ../rtl/mau.v

# Elaborate design hierarchy
hierarchy -check -top mau

#import_files -sdc {yosys_constraints.sdc}

# Translate processes to netlists
proc

# Mapping to the internal cell library
techmap

# Mapping flip-flops to NangateOpenCellLibrary_typical.lib
# for e.g., always block
# Change the library file accordingly
dfflibmap -liberty /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib

# Mapping logic to NangateOpenCellLibrary_typical.lib
# for e.g., assign block
abc \
-D 10000 \
-constr "synthesis.sdc" \
-showtmp \
-liberty /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib

# Remove unused cells and wires
clean

# Write the current design to a Verilog file
write_verilog -noattr mau_gl.v