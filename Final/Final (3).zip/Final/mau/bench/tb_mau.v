`timescale 1ns/10ps

module tb_mau;

parameter PERIOD    = 10;
parameter D_SIZE    = `DATA_SIZE;
parameter D_LAT     = `NUM_PIPELINES_STAGE;
parameter BUF_DEP   = D_LAT+2;

reg                     clk;
reg                     rst_n;
reg                     valid;
reg                     last;
reg    [D_SIZE-1:0]     a_dat;
reg    [D_SIZE-1:0]     b_dat;
reg    [D_SIZE*2-1:0]   c_dat;
wire                    ready;
wire                    done;
wire  [D_SIZE*2:0]      d_dat;

mau
`ifdef RTL_SIM
#(
    .D_SIZE     (D_SIZE),
    .D_LAT      (D_LAT)
)
`endif
DUT
(
    .clk        (clk),
    .rst_n      (rst_n),
    .valid_i    (valid),
    .last_i     (last),
    .a_i        (a_dat),
    .b_i        (b_dat),
    .c_i        (c_dat),
    .ready_o    (ready),
    .done_o     (done),
    .d_o        (d_dat)
);

reg [D_SIZE*2:0]    expected[0:BUF_DEP-1];
reg [D_SIZE-1:0]    a_buf[0:BUF_DEP-1];
reg [D_SIZE-1:0]    b_buf[0:BUF_DEP-1];
reg [D_SIZE*2-1:0]  c_buf[0:BUF_DEP-1];
integer             in_ptr;
integer             out_ptr;

task reset_ptr;
    begin
        in_ptr  = 0;
        out_ptr = 0;
    end
endtask

task write_random_data;
    input  valid_in;
    input  last_in;
    begin
        last    = last_in;
        valid   = valid_in;
        a_dat   = {$random}%(1<<D_SIZE);
        b_dat   = {$random}%(1<<D_SIZE);
        c_dat   = {$random}%(1<<(D_SIZE*2));
        if (valid_in==1) begin
            a_buf[in_ptr]   = a_dat;
            b_buf[in_ptr]   = b_dat;
            c_buf[in_ptr]   = c_dat;
            expected[in_ptr] = a_dat*b_dat+c_dat;
            in_ptr = (in_ptr+1)%BUF_DEP;  
        end
    end    
endtask

initial begin
    $dumpfile("wave.vcd");
    $dumpvars;
    clk     = 1;
    rst_n   = 1;
    valid   = 0;
    last    = 0;
    a_dat   = 0;
    b_dat   = 0;
    c_dat   = 0;
    reset_ptr;
end

always begin
    #(PERIOD/2) clk <= ~clk;
end

always @(posedge clk) begin
    if (ready==1) begin
        if (d_dat === expected[out_ptr]) begin
            $display("[INFO] PASS at %t: %d*%d+%d = %d", $time, a_buf[out_ptr],b_buf[out_ptr],c_buf[out_ptr],d_dat);
            out_ptr <= (out_ptr+1)%BUF_DEP;
        end
        else begin
            $display("[ERROR] FAIL at %t: %d*%d+%d != %d(should be %d)", $time, a_buf[out_ptr],b_buf[out_ptr],c_buf[out_ptr],d_dat,expected[out_ptr]);
            out_ptr <= (out_ptr+1)%BUF_DEP;
            $finish;
        end
    end
end

integer loop_i, loop_j;
reg bubble;

initial begin
    #1;
    #(PERIOD) rst_n = 0;
    #(PERIOD) rst_n = 1;
    for (loop_j=0; loop_j<5; loop_j=loop_j+1) begin
        $display("[INFO] Iteration %d", loop_j);
        reset_ptr;
        for (loop_i=0; loop_i<50; loop_i=loop_i+1) begin
            #(PERIOD);
                bubble = {$random}%2;
                write_random_data(bubble,0);
        end
        #(PERIOD);
            write_random_data(1,1);
        #(PERIOD);
        write_random_data(0,0);
        while (done == 0) begin
            #(PERIOD);
        end
        #(PERIOD);
    end
    $display("[INFO] All tests passed!");
    $finish;
end

endmodule