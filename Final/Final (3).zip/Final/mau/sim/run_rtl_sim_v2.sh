#!/bin/bash

iverilog -c iv_cmd_file_v2.cf
./a.out
rm -fr a.out