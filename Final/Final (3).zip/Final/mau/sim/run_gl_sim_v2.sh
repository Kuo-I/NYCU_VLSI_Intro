#!/bin/bash

iverilog -c iv_cmd_file_gl_v3.cf
./a.out
rm -fr a.out
