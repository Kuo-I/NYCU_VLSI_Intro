#!/bin/bash

grep die__area runs/*/final/metrics.json
