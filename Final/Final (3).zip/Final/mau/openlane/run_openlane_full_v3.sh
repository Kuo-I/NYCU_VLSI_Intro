#!/bin/bash

openlane config_v3.json