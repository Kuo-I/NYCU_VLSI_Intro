#!/bin/bash

# Usage: ./run_open_syn_explore.sh config.json

if [ $# -eq 0 ]
  then
    echo "Usage: /bin/sh run_open_syn_explore.sh <Openlane configuration>.json"
    exit 1 
fi
openlane --flow SynthesisExploration $1