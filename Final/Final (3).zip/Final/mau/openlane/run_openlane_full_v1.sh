#!/bin/bash

openlane config_v1.json