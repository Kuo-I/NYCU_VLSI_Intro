#!/bin/bash

openlane config_v2.json