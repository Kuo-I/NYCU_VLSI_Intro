`timescale 1ns/1ps
module tb_pm32;

    // ────────── DUT 介面──────────
    reg               clk, rst, start;
    reg  [31:0]       mc,  mp;
    wire [63:0]       p;
    wire              done;

    pm32 dut (
        .clk  (clk),
        .rst  (rst),
        .start(start),
        .mc   (mc),
        .mp   (mp),
        .p    (p),
        .done (done)
    );

    // 50 MHz 時脈 (10 ns 週期)
    always #5 clk = ~clk;

    // ────────── 硬體行為期望值函式──────────
    //   ‣ 先做 32-bit 截斷乘法
    //   ‣ 若 mc[31]=1 → 高 32 位全填 1 (sign-extend)
    //   ‣ 若 mc[31]=0 → 高 32 位全填 0 (zero-extend)
    function signed [63:0] mul32_hwstyle;
        input [31:0] mc_abs, mp_abs;
        reg   [31:0] lo32;
    begin
        lo32 = mc_abs * mp_abs;             // 32-bit 乘法截斷
        if (mc_abs[31])
            mul32_hwstyle = { {32{1'b1}}, lo32 };
        else
            mul32_hwstyle = { 32'b0,       lo32 };
    end
    endfunction

    // ────────── 同步 Reset 任務──────────
    task do_reset; begin
        rst <= 1; @(negedge clk);
        rst <= 0; @(negedge clk);           // 再留一拍穩定
    end endtask

    // ────────── 單筆測試任務──────────
    task apply_test(input integer a, input integer b, input integer id);
        reg   [31:0] ua, ub;                // 實際餵 DUT 的 mc / mp
        reg   signed [63:0] expected;
        integer ta, tb;                     // 暫存 (含符號)
    begin
        // ❶ 決定誰進 mc / mp（mp 必須非負）
        if (b < 0) begin
            ta = -a;
            tb = -b;                        // abs(b)
            ua = ta[31:0];                  // mc  (可正可負)
            ub = tb[31:0];                  // mp  (必為正)
        end else begin
            ua = a[31:0];                   // mc
            ub = b[31:0];                   // mp
        end

        // ❷ 硬體風格期望值
        expected = mul32_hwstyle(ua, ub);

        // ❸ 套用向量並啟動
        @(negedge clk);
        mc    <= ua;
        mp    <= ub;
        start <= 1;
        @(negedge clk);
        start <= 0;

        // ❹ 等待完成
        while (!done) @(negedge clk);

        // ❺ 檢查
        if (^p === 1'bx) begin
            $display("[ERROR] Pattern %0d：輸出含有 X/Z", id); $stop;
        end else if ($signed(p) !== expected) begin
            $display("[ERROR] Pattern %0d：%0d * %0d\n  期望=%0d，得到=%0d",
                      id, a, b, expected, $signed(p)); $stop;
        end else begin
            $display("[INFO ] Pattern %0d PASS @%0t：%0d * %0d = %0d",
                      id, $time, a, b, $signed(p));
        end
    end
    endtask

    // ────────── 主測試流程──────────
    initial begin
        $dumpfile("wave.vcd");
        $dumpvars(0, tb_pm32);

        // 上電初始化
        clk = 0; rst = 1; start = 0; mc = 0; mp = 0;
        @(negedge clk); rst = 0; @(negedge clk);

        // 每筆測試前 reset，清除 CSADD 進位暫存
        do_reset(); apply_test( 0,                0, 0);
        do_reset(); apply_test( 1,                1, 1);
        do_reset(); apply_test( 1234,          5678, 2);
        do_reset(); apply_test( -1,               1, 3);
        do_reset(); apply_test(  1,              -1, 4);
        do_reset(); apply_test( -3000,        -4000, 5);
        do_reset(); apply_test( 32'h7FFF_FFFF,    2, 6);
        do_reset(); apply_test(-32'sd2147483648,  1, 7);
        do_reset(); apply_test( -1,              -1, 8);
        do_reset(); apply_test(-32'sd2147483648, -1, 9);

        
        $finish;
    end

endmodule



