`timescale 1ns/1ps
`default_nettype none

module pm32_tb;

    // DUT inputs
    reg         clk;
    reg         rst;
    reg         start;
    reg [31:0]  mc;  // multiplicand
    reg [31:0]  mp;  // multiplier
    // DUT outputs
    wire [63:0] p;   // product
    wire        done;

    // Instantiate the pm32 module (Device Under Test)
    pm32 dut (
        .clk(clk),
        .rst(rst),
        .start(start),
        .mc(mc),
        .mp(mp),
        .p(p),
        .done(done)
    );

    // Clock generator: 10ns period (100 MHz)
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test control signals and verification logic
    integer i;
    reg [63:0] expected_p;  // expected product
    integer pass_count = 0;
    integer fail_count = 0;

    // Test task: perform a single multiplication test
    task run_test;
        input [31:0] test_mc, test_mp;
        input [63:0] test_expected_p;
        input [31:0] test_id;
        begin
            // Initialization
            rst = 1;
            start = 0;
            mc = test_mc;
            mp = test_mp;
            expected_p = test_expected_p;
            #10;
            rst = 0;
            #10;

            // Start multiplication
            start = 1;
            #10;
            start = 0;

            // Wait for 64 clock cycles
            for (i = 0; i < 64; i = i + 1) begin
                #10;
            end

            // Check done signal and product
            if (done === 1 && p === expected_p) begin
                $display("Test %0d PASSED: mc=%h, mp=%h, p=%h (expected %h)", 
                         test_id, test_mc, test_mp, p, expected_p);
                pass_count = pass_count + 1;
            end else begin
                $display("Test %0d FAILED: mc=%h, mp=%h, p=%h (expected %h), done=%b", 
                         test_id, test_mc, test_mp, p, expected_p, done);
                fail_count = fail_count + 1;
            end

            // Wait for done signal to reset
            #10;
        end
    endtask

    // Main test procedure
    initial begin
        // Initialize VCD waveform file
        $dumpfile("pm32_tb.vcd");
        $dumpvars(0, pm32_tb);

        // Initialize signals
        rst = 1;
        start = 0;
        mc = 0;
        mp = 0;
        #20;
        rst = 0;

        // Test Case 1: positive × positive (5 * 3 = 15)
        // Test basic positive multiplication
        run_test(32'd5, 32'd3, 64'd15, 1);

        // Test Case 2: positive × negative (5 * -3 = -15)
        // Verify negative multiplication, two's complement representation
        run_test(32'd5, -32'd3, -64'd15, 2);

        // Test Case 3: negative × positive (-5 * 3 = -15)
        // Further verify negative multiplication
        run_test(-32'd5, 32'd3, -64'd15, 3);

        // Test Case 4: negative × negative (-5 * -3 = 15)
        // Test multiplication of two negatives, should result in a positive
        run_test(-32'd5, -32'd3, 64'd15, 4);

        // Test Case 5: zero × positive (0 * 123 = 0)
        // Test zero multiplication, ensure product is zero
        run_test(32'd0, 32'd123, 64'd0, 5);

        // Test Case 6: positive × zero (123 * 0 = 0)
        // Further verify zero multiplication
        run_test(32'd123, 32'd0, 64'd0, 6);

        // Test Case 7: max positive × 1 (2^31-1 * 1)
        // Test boundary value for positive number
        run_test(32'h7FFFFFFF, 32'd1, 64'h7FFFFFFF, 7);

        // Test Case 8: min negative × 1 (-2^31 * 1)
        // Test boundary value for negative number, two's complement representation
        run_test(32'h80000000, 32'd1, {32'hFFFFFFFF, 32'h80000000}, 8);

        // Test Case 9: small value multiplication (2 * 2 = 4)
        // Test small values, ensure correctness of simple multiplication
        run_test(32'd2, 32'd2, 64'd4, 9);

        // Test Case 10: all 1s pattern (-1 * -1 = 1)
        // Test special pattern, two's complement -1 = 0xFFFFFFFF
        run_test(32'hFFFFFFFF, 32'hFFFFFFFF, 64'd1, 10);

        // Summary of test results
        $display("Test Summary: %0d tests passed, %0d tests failed", pass_count, fail_count);

        // End simulation
        #100;
        $finish;
    end

endmodule
