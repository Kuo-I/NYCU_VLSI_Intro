/*
    A Serial-Parallel Multiplier (SPM)
    Modeled after the design outlined by ATML for their 
    AT6000 FPGA in application notes DOC0716 and DOC0529:
        - https://ww1.microchip.com/downloads/en/AppNotes/DOC0529.PDF
        - https://ww1.microchip.com/downloads/en/AppNotes/DOC0716.PDF
    
    Implemented by mshalan@aucegypt.edu, 2016
*/

`timescale		    1ns/1ps
`default_nettype    none

module spm32 #(parameter SIZE = 32)(
    input wire              clk, 
    input wire              rst,
    input wire              y,
    input wire [SIZE-1:0]   x,
    output wire             p
);
    wire [SIZE-1:1]     pp;
    wire [SIZE-1:0]     xy;

    genvar i;

    CSADD csa0 (.clk(clk), .rst(rst), .x(x[0]&y), .y(pp[1]), .sum(p));
    
    //generate 
    //    for(i=1; i<SIZE-1; i=i+1) begin
    //        CSADD csa (.clk(clk), .rst(rst), .x(x[i]&y), .y(pp[i+1]), .sum(pp[i]));
    //    end 
    //endgenerate
    
    CSADD csa1  (.clk(clk), .rst(rst), .x(x[1]&y),  .y(pp[2]),  .sum(pp[1]));
    CSADD csa2  (.clk(clk), .rst(rst), .x(x[2]&y),  .y(pp[3]),  .sum(pp[2]));
    CSADD csa3  (.clk(clk), .rst(rst), .x(x[3]&y),  .y(pp[4]),  .sum(pp[3]));
    CSADD csa4  (.clk(clk), .rst(rst), .x(x[4]&y),  .y(pp[5]),  .sum(pp[4]));
    CSADD csa5  (.clk(clk), .rst(rst), .x(x[5]&y),  .y(pp[6]),  .sum(pp[5]));
    CSADD csa6  (.clk(clk), .rst(rst), .x(x[6]&y),  .y(pp[7]),  .sum(pp[6]));
    CSADD csa7  (.clk(clk), .rst(rst), .x(x[7]&y),  .y(pp[8]),  .sum(pp[7]));
    CSADD csa8  (.clk(clk), .rst(rst), .x(x[8]&y),  .y(pp[9]),  .sum(pp[8]));
    CSADD csa9  (.clk(clk), .rst(rst), .x(x[9]&y),  .y(pp[10]), .sum(pp[9]));
    CSADD csa10 (.clk(clk), .rst(rst), .x(x[10]&y), .y(pp[11]), .sum(pp[10]));
    CSADD csa11 (.clk(clk), .rst(rst), .x(x[11]&y), .y(pp[12]), .sum(pp[11]));
    CSADD csa12 (.clk(clk), .rst(rst), .x(x[12]&y), .y(pp[13]), .sum(pp[12]));
    CSADD csa13 (.clk(clk), .rst(rst), .x(x[13]&y), .y(pp[14]), .sum(pp[13]));
    CSADD csa14 (.clk(clk), .rst(rst), .x(x[14]&y), .y(pp[15]), .sum(pp[14]));
    CSADD csa15 (.clk(clk), .rst(rst), .x(x[15]&y), .y(pp[16]), .sum(pp[15]));
    CSADD csa16 (.clk(clk), .rst(rst), .x(x[16]&y), .y(pp[17]), .sum(pp[16]));
    CSADD csa17 (.clk(clk), .rst(rst), .x(x[17]&y), .y(pp[18]), .sum(pp[17]));
    CSADD csa18 (.clk(clk), .rst(rst), .x(x[18]&y), .y(pp[19]), .sum(pp[18]));
    CSADD csa19 (.clk(clk), .rst(rst), .x(x[19]&y), .y(pp[20]), .sum(pp[19]));
    CSADD csa20 (.clk(clk), .rst(rst), .x(x[20]&y), .y(pp[21]), .sum(pp[20]));
    CSADD csa21 (.clk(clk), .rst(rst), .x(x[21]&y), .y(pp[22]), .sum(pp[21]));
    CSADD csa22 (.clk(clk), .rst(rst), .x(x[22]&y), .y(pp[23]), .sum(pp[22]));
    CSADD csa23 (.clk(clk), .rst(rst), .x(x[23]&y), .y(pp[24]), .sum(pp[23]));
    CSADD csa24 (.clk(clk), .rst(rst), .x(x[24]&y), .y(pp[25]), .sum(pp[24]));
    CSADD csa25 (.clk(clk), .rst(rst), .x(x[25]&y), .y(pp[26]), .sum(pp[25]));
    CSADD csa26 (.clk(clk), .rst(rst), .x(x[26]&y), .y(pp[27]), .sum(pp[26]));
    CSADD csa27 (.clk(clk), .rst(rst), .x(x[27]&y), .y(pp[28]), .sum(pp[27]));
    CSADD csa28 (.clk(clk), .rst(rst), .x(x[28]&y), .y(pp[29]), .sum(pp[28]));
    CSADD csa29 (.clk(clk), .rst(rst), .x(x[29]&y), .y(pp[30]), .sum(pp[29]));
    CSADD csa30 (.clk(clk), .rst(rst), .x(x[30]&y), .y(pp[31]), .sum(pp[30]));
    
    TCMP tcmp (.clk(clk), .rst(rst), .a(x[SIZE-1]&y), .s(pp[SIZE-1]));

endmodule


// Carry Save Adder
module CSADD(
    input wire  clk, 
    input wire  rst,
    input wire  x, 
    input wire  y,
    output reg  sum
);

    reg sc;

    // Half Adders logic
    wire hsum1, hco1;
    assign hsum1 = y ^ sc;
    assign hco1 = y & sc;

    wire hsum2, hco2;
    assign hsum2 = x ^ hsum1;
    assign hco2 = x & hsum1;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            sum <= 1'b0;
            sc <= 1'b0;
        end
        else begin
            sum <= hsum2;
            sc <= hco1 ^ hco2 ;//+ ({$random}%2);
        end
    end
endmodule

// 2's Complement
module TCMP (
    input wire  clk, 
    input wire  rst,
    input wire  a, 
    output reg  s
);
  
    reg z;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            s <= 1'b0;
            z <= 1'b0;
        end
        else begin
            z <= a | z;
            s <= a ^ z;
        end
    end

endmodule