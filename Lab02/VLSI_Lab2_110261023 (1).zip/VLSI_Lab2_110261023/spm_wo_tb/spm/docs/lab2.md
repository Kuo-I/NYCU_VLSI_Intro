# Laboratory Exercise #2

## 2.1: RTL Reverse Engineering

**Objective:** To understand and document the logic implementation of a given RTL design.

**Instructions:**

1.  Locate the Verilog file for the `pm32` circuit at the specified path: `"rtl/spm32.v"`.
2.  Carefully trace the Register Transfer Level (RTL) implementation of the circuit by examining the Verilog code.
3.  Based on your understanding of the RTL, sketch a logic-level circuit diagram that accurately represents the design. Refer to the provided diagram image (`pm32.diagram.webp`) for the circuit's block-level representation, but your sketch should detail the internal logic gates and flip-flops based on the Verilog code.

![pm32](pm32.diagram.webp)

## 2.2: Testbench Development and Simulation

**Objective:** To create a testbench to verify the functionality of the `pm32` design and simulate its behavior.

**Instructions:**

1.  Develop a testbench for the `pm32` design. Your testbench should instantiate the `pm32` module (your Device Under Test or DUT) and provide stimulus to its inputs.
2.  Generate at least 10 suitable test patterns that thoroughly exercise the functionality of the `pm32` design. Include comments in your testbench explaining the purpose of each test pattern.
3.  Save your testbench file within the `"bench"` directory.
4.  Execute the simulation using the provided control script. Navigate to the `"sim"` directory in your terminal and run the script using the following command:

    ```bash
    cd sim
    ./run_rtl_sim.sh
    ```

5.  Display the simulation results. The output should illustrate the signal waveforms similar to the example provided below, showing the input stimuli and the resulting output responses of the `pm32` module.

![rtl_sim](spm_rtl_sim.JPG)

## 2.3: Logic Synthesis Exploration

**Objective:** To explore the impact of different synthesis strategies and clock periods on the `pm32` design using OpenLane and Yosys.

**Instructions:**

1.  Navigate to the OpenLane directory in your terminal:

    ```bash
    cd openlane
    ```

2.  Explore different logic synthesis strategies provided by OpenLane with Yosys for the `pm32.v` file by running the synthesis exploration script:

    ```bash
    /bin/bash run_openlane_syn_explore.sh
    ```

    This script will likely provide information or generate results related to various synthesis options.

3.  Modify the `config.json` file located in the OpenLane directory. This file contains configuration settings for the synthesis process. You will need to adjust the `"CLOCK_PERIOD"` and `"SYNTH_STRATEGY"` fields.

    ```json
    {
      "DESIGN_NAME": "pm32",
      "VERILOG_FILES": ["dir::../rtl/pm32.v", "dir::../rtl/spm.v"],
      "CLOCK_PERIOD": 15,
      "CLOCK_PORT": "clk",
      "SYNTH_STRATEGY": "AREA 3"
    }
    ```

4.  Your goal is to find the *shortest possible clock period* for each available synthesis strategy without introducing timing violations.
5.  After modifying the `config.json` with a specific synthesis strategy and a chosen clock period, run the full OpenLane flow using the following command from the OpenLane directory:

    ```bash
    /bin/bash run_openlane_full.sh
    ```

6.  After the synthesis run completes, examine the output logs and reports to check for timing violations.
7.  **Correct Result:** A successful synthesis run without timing violations FOR ALL CORNERS will show a result similar to the image below, indicating that all timing constraints were met.

    ![wo-timing-violation](wo-timing-violation.JPG)

8.  **Incorrect Result:** A synthesis run with timing violations will indicate that the design failed to meet the timing requirements for the specified clock period, similar to the image below. In this case, you will need to increase the `CLOCK_PERIOD` in the `config.json` and rerun the full flow.

    ![timing-violation](timing-violation.JPG)

9.  Systematically test different `SYNTH_STRATEGY` values and iteratively reduce the `CLOCK_PERIOD` for each strategy until you find the minimum value that results in a design with no timing violations. Record your findings for each strategy (the strategy used and the shortest achievable clock period without timing violations).