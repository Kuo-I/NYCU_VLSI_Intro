#!/bin/bash

rm -fr ../gl/pm32_gl.v

yosys -s yosys_cmd.tcl

mv pm32_gl.v ../gl/.
