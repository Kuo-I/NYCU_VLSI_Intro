#!/bin/bash

iverilog -c iv_cmd_file_gl.cf
./a.out
rm -fr a.out