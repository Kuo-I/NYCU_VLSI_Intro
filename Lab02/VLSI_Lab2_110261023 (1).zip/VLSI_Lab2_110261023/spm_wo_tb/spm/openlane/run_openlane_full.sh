#!/bin/bash

openlane config.json