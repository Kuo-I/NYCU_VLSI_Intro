#!/bin/bash

openlane --flow SynthesisExploration config.json