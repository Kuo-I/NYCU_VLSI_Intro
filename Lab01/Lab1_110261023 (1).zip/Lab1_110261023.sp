*------------------------------------------------
* Parameters and models
*------------------------------------------------
****choose your corner
.lib /foss/pdks/sky130A/libs.tech/ngspice/sky130.lib.spice sf
**.lib ./spice/libs.tech/ngspice/sky130.lib.spice ff
**.lib ./spice/libs.tech/ngspice/sky130.lib.spice ss
**.lib ./spice/libs.tech/ngspice/sky130.lib.spice fs
**.lib ./spice/libs.tech/ngspice/sky130.lib.spice sf
.include /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice

.global vdd gnd
.temp 70

.param SUPPLY=1.8
             *1.62 1.98
.csparam SUPPLY={SUPPLY}

.param Tdc=20p
.csparam Tdc={Tdc}

*------------------------------------------------ 
* Simulation netlist
*------------------------------------------------
.subckt DFF CLK D Q
XDFFmodel CLK D gnd gnd vdd vdd Q Q_N sky130_fd_sc_hd__dfxbp_1
.ends

.subckt inv A Y
x1 A gnd gnd vdd vdd Y sky130_fd_sc_hd__inv_1     
.ends

***DFF model instantiation
XDFF CLK D Q DFF

***Cload
XINV Q Y inv

*------------------------------------------------
* Stimulus
*------------------------------------------------
Vdd     vdd     gnd     DC  SUPPLY
Vclk    CLK     gnd     PULSE 0 SUPPLY 500ps 10ps 10ps 1990ps 4ns
Vdin    D       gnd     PULSE SUPPLY 0 {4500p-Tdc} 10ps 10ps 10ns 20ns 

*------------------------------------------------
* Control block
*------------------------------------------------
.control
    let SPLY2 = SUPPLY/2
    let Tdc_delay = 120p
    *from 30p to 120p depend on the corners been choosen
    repeat 10
        alterparam Tdc = $&Tdc_delay
        reset
        tran 0.1ps 7ns
        plot v(Q) v(CLK) v(D)
        print Tdc_delay
         meas tran tpcq TRIG v(clk) VAL=SPLY2 RISE=2 TARG v(Q) VAL=SPLY2 FALL=1  
                                                                         *Fall=2 for ff 1.98V & sf 1.8V
        let Tdc_delay = Tdc_delay + 2p
    end
.endc     

.end
